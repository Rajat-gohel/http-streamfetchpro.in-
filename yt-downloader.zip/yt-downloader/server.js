const express = require('express');
const cors = require('cors');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs');

const app = express();
app.use(cors());
app.use(express.json());

// Serve static frontend files from the 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// Setup safe local folder path for downloads
const downloadDir = path.join(__dirname, 'downloads');
if (!fs.existsSync(downloadDir)) {
    fs.mkdirSync(downloadDir);
}
app.use('/files', express.static(downloadDir));

// Download API Routing Logic
app.post('/api/download', (req, res) => {
    const { url, format, quality } = req.body;

    if (!url) {
        return res.status(400).json({ error: 'URL is required' });
    }

    const fileId = Date.now();
    let outputTemplate = path.join(downloadDir, `${fileId}_%(title)s.%(ext)s`);
    let command = '';

    if (format === 'mp3') {
        // Extract best audio stream and convert to MP3
        command = `yt-dlp -f "ba" -x --audio-format mp3 -o "${outputTemplate}" "${url}"`;
    } else {
        // Handle Video Resolutions
        let resFilter = 'bv*';
        if (quality === '4k') resFilter = 'bv*[height<=2160]';
        else if (quality === '1080p') resFilter = 'bv*[height<=1080]';
        else if (quality === '720p') resFilter = 'bv*[height<=720]';
        else if (quality === '480p') resFilter = 'bv*[height<=480]';
        else if (quality === '360p') resFilter = 'bv*[height<=360]';

        if (quality === '4k') {
            // 4K works best in an MKV container to prevent codec/playback errors
            command = `yt-dlp -f "${resFilter}+ba/b" --merge-output-format mkv -o "${outputTemplate}" "${url}"`;
        } else {
            // 1080p and lower work great in a standard MP4 container
            command = `yt-dlp -f "${resFilter}+ba/b" --merge-output-format mp4 -o "${outputTemplate}" "${url}"`;
        }
    }

    exec(command, (error, stdout, stderr) => {
        if (error) {
            console.error(`yt-dlp processing error: ${error.message}`);
            return res.status(500).json({ error: 'Failed to download and convert video. Make sure FFmpeg is installed.' });
        }

        // Read the directory to find the generated file name matching our unique ID
        const files = fs.readdirSync(downloadDir);
        const matchFile = files.find(file => file.startsWith(fileId.toString()));

        if (matchFile) {
            res.json({ 
                downloadUrl: `/files/${encodeURIComponent(matchFile)}`,
                actualExt: path.extname(matchFile).replace('.', '').toUpperCase()
            });
        } else {
            res.status(500).json({ error: 'Processed file storage mapping fault.' });
        }
    });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 Server running perfectly at http://localhost:${PORT}`));